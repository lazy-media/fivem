Tom Grobbe - https://www.vespura.com/

Copyright © 2017-2023

You can use and edit this code to your liking as long as you don't ever claim it to be your own code and always provide proper credit. 
You're **not** allowed to sell vMenu or any code you take from it.
If you want to release your own version of vMenu, you have to link the original GitHub repo, or release it via a Forked repo.
